<body style="zoom: 1; "><center>
  <table cellpadding="0" cellspacing="0" style="margin-bottom:20px;">
    <tbody><tr>
      <td>
        <table class="wrap" style="margin: auto; margin-bottom:5px; font-family: Lato; padding-bottom:10px; position:relative; padding-left:5px; padding-right:10px; margin-bottom:0px; margin-top:5px; padding:10px;padding-top:0; border-left: 1px solid #e4e2e2; border-top: 1px solid #e4e2e2; border-right: 1px solid #e4e2e2; ">
          <tbody><tr>
            <td colspan="3">
              <p class="wrap_text" style="margin-bottom:0px; color: #515050; font-size:12px; margin-top:2px; text-align:center;">
                Made for Mobile
              </p>
            </td>
          </tr>
          <tr>
            <td>
<!-- BUTTON CODE -->   
<center>
    <table border="0" id="button_cl" cellpadding="0" cellspacing="0" style="background-color:#287992;">
      <tbody><tr class="main">
        <td class="main" style="padding:3px 5px 5px 5px;" width="145">
          <table>
            <tbody><tr>
              <td>
                  <img class="cart_icon" src="<?php echo plugins_url( 'images/bttn_cart_white.png' , dirname(__FILE__) );  ?>" style="margin-left: 5px; margin-right:10px; margin-top:8px;">
              </td>
              <td>
                <table border="0" cellpadding="0" cellspacing="0" style="float:left; margin:0; margin-left:0px;">
                  <tbody>
                  <tr>
                    <td>
                      <table border="0" cellpadding="0" cellspacing="0" style="margin:0; padding:0; padding-top:4px;">
                        <tbody><tr>
                          <td style="padding:0; margin:0; font-size: 26px; color: #FFFFFF; font-family: Tahoma; vertical-align:top; line-height:25px;" valign="top">
                              $50
                          </td>
                          <td style="padding:0; margin:0; font-size:14px; text-decoration:underline;padding-left:2px; color: #FFFFFF; font-family: Tahoma; vertical-align:top;" valign="top">
                              95
                          </td>
                        </tr>
                      </tbody></table>
                    </td>
                  </tr>
                </tbody></table>
              </td>
            </tr>
          </tbody></table>
        </td>
      </tr>
    </tbody></table>
</center>

<!-- END BUTTON CODE -->

</td>
          </tr>
        </tbody></table>
      </td>
    </tr>
    <tr>
      <td>
        <table cellpadding="0" cellspacing="0" style="width:100%;" width="100%" style="margin-top:-20px;">
          <tbody><tr>
            <td valign="top">
              <table class="leftb"  cellpadding="0" cellspacing="0" height="10" style="font-size: 1px; line-height: 1px; border-left: 1px #e4e2e2 solid;  border-bottom: 1px #e4e2e2 solid; height:10px; width: 100%;">
                <tbody><tr>
                  <td>
                    &nbsp;
                  </td>
                </tr>
              </tbody></table>
            </td>
            <td width="155">
              <center>
                <img src="<?php echo plugins_url( 'images/email_chout_tag.png' , dirname(__FILE__) );  ?>" class="tag" style="">


              </center>
            </td>
            <td valign="top" width="20">
              <table class="rightb"  cellpadding="0" cellspacing="0" height="10" style="font-size: 1px; line-height: 1px; border-right: 1px #e4e2e2 solid;  border-bottom: 1px #e4e2e2 solid; height:10px; width: 100%;">
                <tbody><tr>
                  <td>
                    &nbsp;
                  </td>
                </tr>
              </tbody></table>
            </td>
          </tr>
        </tbody></table>
      </td>
    </tr>
  </tbody></table>
</center>
</body>