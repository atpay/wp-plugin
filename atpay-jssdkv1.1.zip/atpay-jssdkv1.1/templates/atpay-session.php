<span id='atpayName'></span> 
<a href='#' id="atPayLogout" onclick='atpayLogout();'> Logout </a> 
<a href='#' id="atPayLogin" onclick='atpayLogin();'> Login </a>